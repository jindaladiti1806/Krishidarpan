<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">-->
 <link rel="stylesheet" href="css/bootstrap.min.css">
  
 
</head>
<style>

</style>
<body>
<?php include("header.php"); ?>
<div class="container" style="min-height:527px;">
<div class="row">
<div class="col-lg-12 heading">
<h1>CROP MANAGEMENT FOR ABERRANT WEATHER CONDITIONS</h1><br><br>
</div>
 <ul>
 <li><a href="">DROUGHT MANAGEMENT</a></li><br><br>
 <li><a href="">MOISTURE STRESS MANAGEMENT IN HORTICULTURE CROPS</a></li><br><br>
 <li><a href="">RAIN DEFICIT MOISTURE STRESS MANAGEMENT IN FRUIT CROPS</a></li><br><br>
 <li><a href="">RAIN DEFICIT MOISTURE STRESS MANAGEMENT IN VEGETABLES</a></li><br><br>
 <li><a href="">RAIN DEFICIT MOISTURE STRESS MANAGEMENT IN PLANTATION CROPS</a></li><br><br>
 <li><a href="">RAIN DEFICIT MANAGEMENT STRESS MANAGEMENT IN SPICES</a></li><br><br>
 <li><a href="">SMART PRACTICES AND TECHNOLOGY FOR CLIMATE RESILIENT AGRICULTURE</a></li><br><br>
 <li><a href="">CONTIGENCY PLAN FOR RICE UNDER ABERRANT WEATHER SITUATIONS</a></li><br><br> 
 </ul>
	
</div>
</div>
</div>

<?php include("footer.php"); ?>
	
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>-->
 <script src="js/jquery.min.js"></script>
   <script src="js/jquery.js"></script>
</body>
</html>