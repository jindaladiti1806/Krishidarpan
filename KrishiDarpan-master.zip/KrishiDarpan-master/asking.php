<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">-->
 <link rel="stylesheet" href="css/bootstrap.min.css">
  
 
</head>
<style>
body {
	background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url(image.jpg);
}
.info {
	border: 1px solid white;
	padding:10px 10px;
	color:#fff;
	text-decoration: none;
	font-size: 13px;
	margin:20px 1px 5px 1px;
	text-align:center; 
}
.info a{
	text-decoration: none;
	color:#fff;
}
</style>
<body>
<?php include("header.php"); ?>
<div class="container">
<div class="row">
<div class="col-lg-6">
	<div class="info"><a href="#" >As Farmer</a></div>
</div>
<div class="col-lg-6">
	<div class="info"><a href="#">As Vendor</a></div>
</div>
</div>
</div>
<footer>
</footer>
	
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>-->
 <script src="js/jquery.min.js"></script>
  <script src="js/jquery.js"></script>
</body>
</html>