	<?php
$db = new PDO('mysql:host=localhost;dbname=registration;charset=utf8mb4','root','');
?>