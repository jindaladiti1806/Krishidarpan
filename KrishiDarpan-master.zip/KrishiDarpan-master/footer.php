 <style>
  button a{
     font-family:Ink free;
     color:#fff;
}     
</style>
<head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">-->
 <link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"">

  
 
</head>

    <footer id="footer" style="background-color: #333333;">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <h3 style="font-family:papyrus; font-size: 32px;color: #fff;">Who We Are</h3>
                            <p style="font-size:15px; font-family:Ink Free;color:green;">Agriculture is the backbone of the Indian Economy"- said Mahatma Gandhi six decades ago.</p>
                            <button type="button" class="btn btn-sm btn-success" ><a href="About Us.php">Read More...</a></button>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 style="font-size:20px; font-family:papyrus;;font-size: 32px;color: #fff;">Useful Links</h4>
                        <ul>
                            <li style="font-size:16px; font-family:Ink Free;color:green;"><i class="ion-ios-arrow-right"></i><a href="index.php">Home</a></li>
                            <li style="font-size:16px; font-family:Ink Free;color:green;"><i class="ion-ios-arrow-right"></i><a href="About Us.php">About us</a></li>
                            <li style="font-size:16px; font-family:Ink Free;color:green;"><i class="ion-ios-arrow-right"></i><a href="practise.php">FAQs</a></li>
                            </li>
                           </ul>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 style="font-size:20px; font-family:papyrus; font-size: 32px;color: #fff">Follow Us On</h4>
                        <a href="https://www.twitter.com/" style="font-size:25px"; class="twitter"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.facebook.com/" style="font-size:25px"; class="facebook"><i class="fa fa-facebook"></i></a>
                        <a href="https://www.instagram.com/" style="font-size:25px"; class="instagram"><i class="fa fa-instagram"></i></a>
                        <a href="https://plus.google.com/" style="font-size:25px"; class="google-plus"><i class="fa fa-google-plus"></i></a>
                        <a href="https://www.linkedin.com/" style="font-size:25px"; class="linkedin"><i class="fa fa-linkedin"></i></a>
                    </div>
                
                    </div>
                </div>
            </div>
        </div>
    </footer>
    